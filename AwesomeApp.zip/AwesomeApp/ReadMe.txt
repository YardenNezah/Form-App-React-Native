React Native Application using react native cli:

An App with the components:
-Header
-Footer
-Body: 
      -Form
      -Submit