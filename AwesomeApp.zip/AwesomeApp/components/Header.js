const Header = () => {
    return (
        <View>
            <Text>
                Header
            </Text>
            <Button>flashlight</Button>
        </View>
    );


}

export default Header;
