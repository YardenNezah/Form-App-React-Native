import React, {useState} from 'react';
import {Text, StyleSheet, View, TextInput} from 'react-native';
import {Picker} from '@react-native-picker/picker';
const Form = () => {
    const [gender, setGender] = useState('Female');
    return (
        <View>
            <Text>
                Personal Form
            </Text>
            <TextInput placeholder="Enter Your Full Name"/>
            <TextInput placeholder="Enter Your Email"/>
            <TextInput placeholder="Enter Your ID Number"/>
            <Picker selectedValue={gender}
                onValueChange={
                    currentGender => setGender(currentGender)
            }>
                <Picker.Item label="Female" value="Female"/>
                <Picker.Item label="Male" value="Male"/>
            </Picker>
            <Text>
                Selected Gender: {gender} </Text>
        </View>
    );


};

const styles = StyleSheet.create({ // Check project repo for styles
});


export default Form;
