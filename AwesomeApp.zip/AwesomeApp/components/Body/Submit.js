import {Alert} from "react-native";
let count = 0;

const Submit = () => {
    const onSubmit = () => {
        count++;
        Alert.alert(count);
    }
    return (
        <View>
            <button title="Submit"
                style={
                    style.Button
                }
                onKeyPress={
                    (onSubmit)
            }>
                Submit
            </button>
            <Text>
                The Number Of Submits is: {count} </Text>
        </View>
    )

}

export default Submit;
