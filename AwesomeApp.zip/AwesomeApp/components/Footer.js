const Footer = () => {
    return (
        <Text></Text>
    );


}

export default Footer;
